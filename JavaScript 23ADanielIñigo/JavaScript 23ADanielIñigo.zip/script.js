fetch("Paises.csv")
.then(response=>response.text())
.then(data=>listadoPaises(data));

function listadoPaises(data){
    const tablaPrincipalPaises=document.createElement("table");
    tablaPrincipalPaises.border="1px solid black";
    tablaPrincipalPaises.style.borderCollapse="collapse";
    document.body.appendChild(tablaPrincipalPaises);
    let fila=[];
    fila=data.split("\n")
    const thead=document.createElement("thead");
    tablaPrincipalPaises.appendChild(thead);
    const th=document.createElement("th");
    fila.forEach(item=> {
    let id=item=fila[0]
    id=item.split(";")
    th.textContent=id
    });
    thead.appendChild(th);
    const tbody=document.createElement("tbody");
    tablaPrincipalPaises.appendChild(tbody);
    const td=document.createElement("td");
    fila.forEach(item=> {
        let id=item=fila[1]
        id=item.split(";")
        td.textContent=id
        });
    tbody.appendChild(td)
}